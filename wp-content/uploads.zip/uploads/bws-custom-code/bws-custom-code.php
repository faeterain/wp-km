<?php
if ( ! defined( 'ABSPATH' ) ) exit;
if ( ! defined( 'BWS_GLOBAL' ) ) exit;

/* Start your code here */